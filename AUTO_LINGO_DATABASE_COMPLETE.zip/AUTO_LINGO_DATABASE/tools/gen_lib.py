import json
D="2026-11-11"
def build(rows,start):
    out=[]
    for i,r in enumerate(rows,start):
        (en,fa,pr,ipa,kind,cat,df,simple,fn,loc,pri,sym,tst,rel,ex,exfa,syn,diff)=r
        out.append(dict(id=f"TERM-{i:06d}",term_en=en,term_fa=fa,pronunciation_fa=pr,ipa=ipa,kind=kind,category_id=cat,
          technical_definition=df,simple_explanation=simple,function=fn,location=loc,working_principle=pri,
          common_symptoms=sym,testing_method=tst,related_terms=rel,example_en=ex,example_fa=exfa,synonyms=syn,
          difficulty=diff,verification_status="unverified",last_reviewed_at=D))
    return out
