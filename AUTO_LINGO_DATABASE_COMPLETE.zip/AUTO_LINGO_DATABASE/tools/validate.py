import json,glob,re,collections,sys
root="AUTO_LINGO_DATABASE"
cats={c["id"] for c in json.load(open(f"{root}/categories.json"))}
req=["id","term_en","term_fa","pronunciation_fa","ipa","kind","category_id","technical_definition","simple_explanation","function","location","working_principle","common_symptoms","testing_method","related_terms","example_en","example_fa","synonyms","difficulty","verification_status","last_reviewed_at"]
terms=[]
for f in sorted(glob.glob(f"{root}/terms/terms_batch_*.json")):
    terms+=json.load(open(f))
errs=[]
ids=[t["id"] for t in terms]
for k,v in collections.Counter(ids).items():
    if v>1: errs.append(f"dup id {k}")
nums=[int(i.split('-')[1]) for i in ids]
if nums!=list(range(1,len(nums)+1)): errs.append("ids not contiguous")
names=collections.Counter(t["term_en"].lower() for t in terms)
errs+= [f"dup term_en {k}" for k,v in names.items() if v>1]
pf=["function","location","working_principle","common_symptoms","testing_method"]
for t in terms:
    for r in req:
        if r not in t: errs.append(f"{t['id']} missing {r}")
    if t["category_id"] not in cats: errs.append(f"{t['id']} bad category")
    if t["verification_status"] not in("verified","unverified","needs_review","unknown"): errs.append(f"{t['id']} bad status")
    if t["kind"]=="part":
        for p in pf:
            if not t[p]: errs.append(f"{t['id']} part missing {p}")
    else:
        for p in pf:
            if t[p] is not None: errs.append(f"{t['id']} non-part has {p}")
    for p in ["technical_definition","simple_explanation"]:
        if re.search(r"\d",t[p] or ""): errs.append(f"{t['id']} digit in {p} (check: numeric value needs source)")
    if not re.search(r"[\u0600-\u06FF]",t["term_fa"]): errs.append(f"{t['id']} term_fa not Persian")
have={t["term_en"].lower() for t in terms}|{s.lower() for t in terms for s in t["synonyms"]}
unres=collections.Counter(r for t in terms for r in t["related_terms"] if r.lower() not in have)
st=collections.Counter(t["verification_status"] for t in terms)
bycat=collections.Counter(t["category_id"] for t in terms)
print("terms",len(terms),"errors",len(errs)); print(errs[:20]); print(dict(st)); print(dict(sorted(bycat.items())))
print("unresolved related terms:",len(unres),sorted(unres))
json.dump({"count":len(terms),"status":st,"by_category":bycat,"unresolved_related":sorted(unres)},open("val.json","w"),default=dict)
