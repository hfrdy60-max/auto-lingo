# AUTO LINGO — Progress Log (آخرین به‌روزرسانی: 2026-11-12)

## وضعیت
- Stage 1 — معماری دیتابیس: انجام شد (database_schema.sql، categories, brands, sources)
- Stage 2 — اصطلاحات: در حال انجام — 82 از حداقل 1000
  - terms_batch_01.json: TERM-000001..000041 (CAT-01, 02, 03)
  - terms_batch_02.json: TERM-000042..000082 (CAT-04, 05, 06, 07)
  - **آخرین شناسه: TERM-000082 — ادامه از TERM-000083**
- Stages 3–10: شروع نشده

## تعداد اصطلاح در هر دسته
{"CAT-01": 21, "CAT-02": 12, "CAT-03": 8, "CAT-04": 12, "CAT-05": 8, "CAT-06": 8, "CAT-07": 13}
دسته‌های بدون هیچ اصطلاح: CAT-08 تا CAT-26

## کنترل کیفیت (tools/validate.py)
- خطای ساختاری: 0 | شناسه تکراری: 0 | term_en تکراری: 0 | فیلدهای null برای غیرقطعه‌ها: درست
- همه 82 رکورد: unverified (منبع مشخصی در entity_sources ثبت نشده است)
- هیچ عدد فنی (ولتاژ، فشار، گشتاور، مقاومت) در تعاریف نیست

## بدهی داده: اصطلاحات ارجاع‌شده که هنوز رکورد ندارند (31 مورد)
Air Filter, Bearing, CAN Bus, Catalytic Converter, Clutch, Compression Stroke, Connector, Continuity, Cooling Fan, Drain Plug, Duty Cycle, Exhaust System, Fault Code, Flashing, Fuel Pressure, Ground, Immobilizer, LTFT, Live Data, Lubrication System, Normally Closed, Normally Open, Oil Pump, Overheating, Resistance, STFT, Sensor, Tensioner, Thermostat, Vacuum Leak, Wiring Harness
این‌ها باید در بسته‌های بعدی ساخته شوند تا related_terms کامل شود.

## موارد ناقص
- ipa و pronunciation_fa تقریبی‌اند و بازبینی زبانی نشده‌اند
- ترجمه‌های فارسی نیاز به بازبینی مکانیک/مترجم فنی دارند
- فایل‌های parts, systems, vehicle_models, vehicle_specifications, diagnostics, repair_scenarios, lessons, quizzes هنوز ساخته نشده‌اند
- جدول entity_sources خالی است
