# AUTO LINGO – AI-3 Diagnostic Terminology Bank (Pilot)
Delivery target: data/inbox/chatgpt3/
Phase: 1 (pilot) – Autel MaxiSys MS906 Pro / Pro-TS
Schema: entry.schema.json (minimal). device/source schemas are not written yet.
Dates: last_checked 2026-11-12.
Rules: menu names only from the official manual; Persian translation/pronunciation/examples are author work and flagged (translation_status, workshop_example_status).
