# گزارش تحقیق – فاز ۱ (پایلوت Autel)

**دستگاه:** Autel MaxiSys MS906 Pro / MS906 Pro-TS (VCI: MaxiVCI V200)
**منبع:** راهنمای رسمی کاربر، نسخه‌ی US V2.1، میزبانی‌شده در autel.us (`src-001`)
**تاریخ دسترسی:** 2026-11-12
**تعداد رکورد:** ۳۶ (همگی `verified` از نظر نام منو)

## نسخه‌ی نرم‌افزار
در راهنما شماره‌ی build نرم‌افزار دیاگ چاپ نشده، فقط نسخه‌ی خود راهنما (V2.1) هست. `software_version` عمداً `null` ثبت شد. برای ثبت دقیق باید از خود دستگاه (Settings → About) خوانده شود.

## پوشش
| بخش مهم | وضعیت | یادداشت |
|---|---|---|
| ECU Information | پوشش داده شد | p.33 |
| Read Codes | پوشش داده شد | p.34 |
| Clear Codes | با نام Erase Codes | p.35 |
| Live Data | پوشش کامل دکمه‌ها | p.36-41 |
| Freeze Frame | پوشش داده شد | p.34-35 |
| Active Test | پوشش داده شد | p.41-42 |
| Adaptation | فقط به‌صورت نام جایگزین Special functions | p.32, p.42 |
| Special Functions | پوشش داده شد | p.42-43 |
| System Scan | با نام Auto Scan | p.30-31 |
| OBD-II | ۱۱ زیرمنو | p.44-48 |
| ABS / Airbag | فقط ABS/SRS Services در Service | p.44 |
| Actuation Test, Coding, Programming, BCM, Engine Management, CAN Network | در این راهنما پیدا نشد | به unverified_items.md رجوع کنید |

## نکات قابل‌توجه برای آموزش
- **Erase Codes** در Autel معادل "Clear Codes" است. دو اصطلاح مشابه دیگر هم هست و ادغام نشده‌اند: **Quick erase** (Auto Scan)، **Clear DTCs** (TPMS) و **Erase Codes** در بخش OBDII.
- **Freeze frame** (داده‌ی ذخیره‌شده با DTC) با دکمه‌ی **Freeze** در Live Data (ثابت‌کردن نمایش) فرق دارد.
- منوی **Active test** طبق راهنما ممکن است با نام Actuators، Actuator Test یا Function Tests ظاهر شود.
- **Special functions** ممکن است Control unit adaptations، Variant coding یا Configuration نام بگیرد.

## محدودیت‌ها
- فقط یک راهنما بررسی شد. منوهای خاص هر برند خودرو (مثلاً BMW) در این راهنما نیست.
- تصاویر هنوز جمع‌آوری نشده (`media_index.json` خالی).
- مثال‌های تعمیرگاهی ساخته‌ی نویسنده‌اند (`author_generated`). برای ۱۱ رکورد OBDII هنوز مثال کامل نوشته نشده.
- ترجمه و تلفظ پیشنهادی من است و بازبینی انسانی نشده.
