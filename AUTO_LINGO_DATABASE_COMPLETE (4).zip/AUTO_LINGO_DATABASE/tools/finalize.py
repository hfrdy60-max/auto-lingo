import json,glob,subprocess,os
v=json.load(open("val.json"))
last=v["count"]
batches=sorted(glob.glob("AUTO_LINGO_DATABASE/terms/terms_batch_*.json"))
lines=[]
for f in batches:
    t=json.load(open(f)); cats=sorted({x["category_id"] for x in t})
    lines.append(f"  - {os.path.basename(f)}: {t[0]['id']}..{t[-1]['id']} ({cats[0]}..{cats[-1]})")
allc=[f"CAT-{i:02d}" for i in range(1,27)]
empty=[c for c in allc if c not in v["by_category"]]
nparts=sum(1 for f in batches for x in json.load(open(f)) if x["kind"]=="part")
md=f"""# AUTO LINGO — Progress Log (آخرین به‌روزرسانی: 2026-11-12)

## وضعیت
- Stage 1 — معماری دیتابیس: انجام شد
- Stage 2 — اصطلاحات: در حال انجام — {last} از حداقل 1000
{chr(10).join(lines)}
  - **آخرین شناسه: TERM-{last:06d} — ادامه از TERM-{last+1:06d}**
- دسته‌های بدون اصطلاح: {', '.join(empty)}
- Stages 3–10: شروع نشده

## تعداد اصطلاح در هر دسته
{json.dumps(v['by_category'],ensure_ascii=False)}

## کنترل کیفیت (tools/validate.py)
- خطای ساختاری 0؛ شناسه/term_en تکراری 0؛ همه رکوردها unverified؛ بدون عدد فنی در تعاریف

## بدهی داده: {len(v['unresolved_related'])} اصطلاح ارجاع‌شده بدون رکورد
{', '.join(v['unresolved_related'])}

## موارد ناقص
- IPA و تلفظ فارسی تقریبی؛ ترجمه‌ها نیازمند بازبینی فنی
- منبع در entity_sources ثبت نشده
- parts, systems, vehicle_models, vehicle_specifications, diagnostics, repair_scenarios, lessons, quizzes ساخته نشده
"""
open("AUTO_LINGO_DATABASE/PROGRESS.md","w").write(md)
rep=f"""AUTO LINGO — گزارش وضعیت بسته (2026-11-12)
تعداد کل اصطلاحات: {last} (هدف حداقل 1000)
تعداد قطعات: 0 فایل جدا ({nparts} اصطلاح با kind=part داخل terms)
سیستم‌ها: 0 | کدهای خطا: 0 | درس‌ها: 0 | آزمون‌ها: 0
Verified: 0 | Unverified: {last} | Needs review: 0
فایل‌ها: database_schema.sql, categories.json, brands.json, sources.json, {', '.join('terms/'+os.path.basename(b) for b in batches)}, tools/, PROGRESS.md
تکمیل‌نشده: اصطلاحات دسته‌های خالی و بقیه، parts, systems, vehicle_models, vehicle_specifications, diagnostics, repair_scenarios, lessons, quizzes, entity_sources
"""
open("AUTO_LINGO_DATABASE/REPORT.txt","w").write(rep)
for n in ("PROGRESS.md","REPORT.txt"): open("/mnt/user-data/outputs/"+n,"w").write(open("AUTO_LINGO_DATABASE/"+n).read())
z="/mnt/user-data/outputs/AUTO_LINGO_DATABASE_COMPLETE.zip"
if os.path.exists(z): os.remove(z)
subprocess.run(["zip","-r","-q",z,"AUTO_LINGO_DATABASE"],check=True)
print(subprocess.run(["unzip","-tq",z],capture_output=True,text=True).stdout)
print(last,nparts,empty)
