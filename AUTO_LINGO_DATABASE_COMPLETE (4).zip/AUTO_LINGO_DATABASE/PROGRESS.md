# AUTO LINGO — Progress Log (آخرین به‌روزرسانی: 2026-11-12)

## وضعیت
- Stage 1 — معماری دیتابیس: انجام شد
- Stage 2 — اصطلاحات: در حال انجام — 252 از حداقل 1000
  - terms_batch_01.json: TERM-000001..TERM-000041 (CAT-01..CAT-03)
  - terms_batch_02.json: TERM-000042..TERM-000082 (CAT-04..CAT-07)
  - terms_batch_03.json: TERM-000083..TERM-000129 (CAT-08..CAT-13)
  - terms_batch_04.json: TERM-000130..TERM-000175 (CAT-14..CAT-19)
  - terms_batch_05.json: TERM-000176..TERM-000216 (CAT-01..CAT-22)
  - terms_batch_06.json: TERM-000217..TERM-000252 (CAT-21..CAT-26)
  - **آخرین شناسه: TERM-000252 — ادامه از TERM-000253**
- دسته‌های بدون اصطلاح: 
- Stages 3–10: شروع نشده

## تعداد اصطلاح در هر دسته
{"CAT-01": 25, "CAT-02": 13, "CAT-03": 8, "CAT-04": 12, "CAT-05": 9, "CAT-06": 10, "CAT-07": 14, "CAT-08": 10, "CAT-09": 7, "CAT-10": 11, "CAT-11": 7, "CAT-12": 7, "CAT-13": 6, "CAT-14": 10, "CAT-15": 7, "CAT-16": 8, "CAT-17": 4, "CAT-18": 5, "CAT-19": 12, "CAT-20": 16, "CAT-21": 5, "CAT-22": 11, "CAT-23": 7, "CAT-24": 7, "CAT-25": 7, "CAT-26": 14}

## کنترل کیفیت (tools/validate.py)
- خطای ساختاری 0؛ شناسه/term_en تکراری 0؛ همه رکوردها unverified؛ بدون عدد فنی در تعاریف

## بدهی داده: 2 اصطلاح ارجاع‌شده بدون رکورد
Seat Belt Pretensioner, Suspension

## موارد ناقص
- IPA و تلفظ فارسی تقریبی؛ ترجمه‌ها نیازمند بازبینی فنی
- منبع در entity_sources ثبت نشده
- parts, systems, vehicle_models, vehicle_specifications, diagnostics, repair_scenarios, lessons, quizzes ساخته نشده
